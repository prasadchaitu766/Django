

function check() {
    res = document.getElementById("one");
    window.location.href = "/getCityFromState/?state="+res.value

}