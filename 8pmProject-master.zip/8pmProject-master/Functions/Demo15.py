
def fun1():
    a = 10
    b = 20
    c = 30
    return a,b,c

x,y,z = fun1()
print(x,y,z)
