
def sample(*a):
    print(a)
    print(type(a))

sample()
sample(10)
sample(10,20)
sample(10,20,30)
sample(10,20,30,"Ravi")
sample(10,20,30,"Ravi",125000.00)
