
def fun1():
    a = 10
    b = "Sathya"
    c = False
    d = 10.25
    return a,b,c,d

y = fun1()
print(y)
print(type(y))