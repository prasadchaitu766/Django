
a = 100
x = id(a)
print(x) # 1771010624
y = type(a)
print(y)  #  <class 'int'>
z = int("10")
print(z) # 10
s = print("Hello world")



print(s) #
