

def display(idno=0,name=None,salary="not given"):
    print("Employee IDNO = ",idno)
    print("Employee NAME = ",name)
    print("Employee SALARY = ",salary)

display(101,salary=125000.00)