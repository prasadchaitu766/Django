def fun1():
    print("Function 1")

def fun2():
    print("Function 2")

def fun3():
    print("Function 3")

fun2()
fun1()
fun3()