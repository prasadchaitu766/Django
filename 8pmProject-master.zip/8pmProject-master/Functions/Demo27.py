
def fun1(**a):
    print(a)

fun1()
fun1(idno=101)
fun1(idno=101,name="kumar")
fun1(idno=101,name="kumar",salary="185000.00")