a = 100

def display():
    print(a)
    a = 500

print(a)
display()