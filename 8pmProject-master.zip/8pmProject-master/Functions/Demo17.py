
def fun1(name):
    print(name)

x = fun1("Ravi")
print(x) #  None