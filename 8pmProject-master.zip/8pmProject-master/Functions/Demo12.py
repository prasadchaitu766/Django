
def fun1():
    a = 10
    b = 20
    return a+b

x = fun1()
print(x)
print(type(x))