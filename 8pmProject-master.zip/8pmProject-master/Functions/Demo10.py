
def fun1(x,y,z):
    print(x,y,z)

fun1(10,20,30)
fun1("sathya","python","Naveen")
fun1(10,"Sathya",True)