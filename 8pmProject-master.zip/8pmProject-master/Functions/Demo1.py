def display():
    print("Hi")
    print("Function Example")

display()
