
def sample(b,c="Sathya",*d):
    print("b = ",b)
    print("c = ",c)
    print("d = ",d)

sample(10,20,30,40,50,70)
sample(10,"Tech",5,6,7,8,9,10)
