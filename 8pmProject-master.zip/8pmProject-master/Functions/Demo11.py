
def add(x,y):
    print("The Add = ",x+y)

add(10,20) # 30
add("sathya","Tech") # sathyaTech
add("10","20") # 1020
# add("Sathya",True) # Error
add(True,True) # 2 True Means 1 False means 0
# add("Sathya",1) # Error
add(True,1) # 2
add(True,100) # 101
add(True,10.35) # 11.35