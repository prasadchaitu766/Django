
def sample(x,y=0):
    print(x,y)

