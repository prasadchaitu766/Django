
def fun1(*a):
    print(a)

fun1()
fun1(10)
fun1(10,20)
fun1(10,"Sathya",False)