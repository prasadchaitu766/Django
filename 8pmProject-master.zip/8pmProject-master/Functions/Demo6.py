a = 100 # Global variable

def display():
    a = 2000 # local variable
    print(a)

print(a)
display()
print(a)