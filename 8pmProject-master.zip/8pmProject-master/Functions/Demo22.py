
def display(idno,name,salary):
    print("Employee IDNO = ",idno)
    print("Employee NAME = ",name)
    print("Employee SALARY = ",salary)


display(salary=125000.00,name="Ravi",idno=101)