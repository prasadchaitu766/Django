

def sample(x=0,y=0):
    print(x,y)

sample()
sample(100)
sample(10,20)