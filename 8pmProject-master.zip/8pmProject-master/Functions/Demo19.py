
def sample(x,y):
    print(x)
    print(y)

sample()