def show():
    print("Hi")
    print("This is show")

print("Hello")
show()
print("One")
show()
print("Two")
show()
print("Thanks")
      
