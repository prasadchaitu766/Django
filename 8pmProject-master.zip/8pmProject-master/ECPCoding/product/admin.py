from django.contrib import admin
from .models import Categories
from .models import Product

admin.site.register(Categories)
admin.site.register(Product)


