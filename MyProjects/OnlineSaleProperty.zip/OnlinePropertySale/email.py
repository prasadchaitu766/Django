
# s=input("name")
# str=s[::-1]
# print(str)
# l=[10,45,67]
# l2=l.reverse()
# print(l)
# num = int(input("Number to make table : "))
# li_a = [num for num in range(0 ,num * 11, num)]
#
# for digit in li_a:
#     print(digit)
# import webbrowser
# import time
#
#
#
# make_use = 1
#
# while make_use < 3 :
# 	time.sleep(10)
# 	webbrowser.open("https://www.youtube.com/results?search_query=comedy+pranks")
# make_use = make_use + 1
import random
import turtle
t = turtle.Pen()

for i in range(150):
    t.color(random.choice(['green','red','violet','black']))
    t.width(5)
    t.forward(i)
t.right(30)