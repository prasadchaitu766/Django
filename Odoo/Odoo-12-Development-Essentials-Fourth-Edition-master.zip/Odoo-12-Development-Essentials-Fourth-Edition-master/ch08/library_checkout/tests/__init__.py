from . import test_checkout_mass_message
